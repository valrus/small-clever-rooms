---
layout: post.html
title: "25 Reasons to Spirit Siege Day 23: It's a pretty safe bet"
tags: [spirit_siege, 25_reasons_to_spirit_siege]
summary: "Reason number 23 of #25ReasonsToSpiritSiege: At this point, it's almost certainly going to fund."
---

This post is part of the [#25ReasonsToSpiritSiege]({{ get_url('2014/09/01/Spirit_Siege_Day_1/index.html') }}) series. Click that link for a summary!

As of late this morning, *Spirit Siege* is more than ninety percent of the way to funding. Just last night my partner and I were feeling stressed that we had so far to go, and then overnight, as if by magic (but actually because of the generosity of friends, family and strangers) it turned into pretty close to a sure bet. So today's reason to support *Spirit Siege* is also my sigh of relief: it's almost certainly going to fund, and so whatever you hope to get out of backing it, you're probably going to get it.

It's been a really taxing month, basically having to ask a lot of people for money when I generally assume that they would prefer to be left alone. After that, it's equally a relief to see things start looking good in just the last few days. There's still a little further to go, but it feels less urgent and more hopeful. This post is really just an excuse to kick back and indulge that feeling a little.

Right now there's a couple thousand bucks or so to go on the Kickstarter. We can do that, no problem. [Let's help bring it home.](http://www.kickstarter.com/projects/1796662059/spirit-siege-your-five-minute-strategy-game-fix)