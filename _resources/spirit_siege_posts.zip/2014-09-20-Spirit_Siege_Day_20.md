---
layout: post.html
title: "25 Reasons to Spirit Siege Day 20: The Redmond Internetpocalypse"
tags: [spirit_siege, 25_reasons_to_spirit_siege]
summary: "Reason number 20 of #25ReasonsToSpiritSiege: The Spirit Siege team carries on in the face of hardship."
---

This post is part of the [#25ReasonsToSpiritSiege]({{ get_url('2014/09/01/Spirit_Siege_Day_1/index.html') }}) series. Click that link for a summary!

Reason number 20 that you should support _Spirit Siege_ is that thanks to some chucklehead backhoe-wielding construction worker, thousands of Redmond, WA residents including a majority of the members of Nova Heartbeat were without internet in their homes (such as the one that serves as the development studio) for a whole weekend. As you might guess, one week before the launch of their Kickstarter is not the best time for this to have happened. In fact it was just about the worst possible such time.

Nevertheless, the Kickstarter's daily updates continued to roll out, with people driving thumb drives containing precious specs and artwork across town when necessary. This post is to commemorate the Great Redmond Internetpocalypse of 2014 and the hard work of Nova Heartbeat in carrying on despite it. And, of course, to convince people to [back their project](http://www.kickstarter.com/projects/1796662059/spirit-siege-your-five-minute-strategy-game-fix).