---
layout: post.html
title: "25 Reasons to Spirit Siege Day 16: Dethrone Ben"
tags: [spirit_siege, 25_reasons_to_spirit_siege]
summary: "Reason number 16 of #25ReasonsToSpiritSiege: The best Spirit Siege player in the world is its lead designer. That's messed up."
---

This post is part of the [#25ReasonsToSpiritSiege]({{ get_url('2014/09/01/Spirit_Siege_Day_1/index.html') }}) series. Click that link for a summary!

Reason 16 to support _Spirit Siege_ is that someone needs to dethrone Ben as the world champion.

Ben is the lead game designer on _Spirit Siege_, and he's also the undisputed current world champion at it. He's also a pro-level _Magic: The Gathering_ player, and paraphrasing his own words, _Spirit Siege_ is "basically designed to play to my strengths". So he mostly destroys anyone he plays against. Granted, that's only about four people. But still.

Son, that ain't right.

Somewhere out there in the wide world is a person who will be better at _Spirit Siege_ than Ben is. But the only way to find them will be to cast a wide net, and the only way to do that is to make sure that _Spirit Siege_ gets made so it can start being more widely distributed, the sooner the better.

[Help stop Ben's reign of terror by supporting _Spirit Siege_.](https://www.kickstarter.com/projects/1796662059/spirit-siege-your-five-minute-strategy-game-fix) Every second it's not available to anyone on the Android and Apple app stores is a second that Ben might be practicing. A successful Kickstarter will hasten the search for the Chosen One who will topple the king.
