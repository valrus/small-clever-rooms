---
layout: post.html
title: "25 Reasons to Spirit Siege Day 15: They've already earned it"
tags: [spirit_siege, 25_reasons_to_spirit_siege]
summary: "Reason number 15 of #25ReasonsToSpiritSiege: If you think that a day's work deserves a day's pay, the team's already earned $50K."
---

This post is part of the [#25ReasonsToSpiritSiege]({{ get_url('2014/09/01/Spirit_Siege_Day_1/index.html') }}) series. Click that link for a summary!

I'm tired and it's late so today I have a pretty simple reason that you should back _Spirit Siege_ on Kickstarter: if you think that people should get paid for work that they do, the nine people who have been working on it for the last several months (totaling probably at least three person-years of normal work weeks) have already earned it. I'm not sure about the specifics of who's worked how many hours per week for how long, but any way you slice the math, this Kickstarter funding will pay them _way_ less than they could be making elsewhere even before the various services involved take their cut, and probably somewhere in the vicinity of minimum wage.

[So toss them a few bucks for the work they've already done.](https://www.kickstarter.com/projects/1796662059/spirit-siege-your-five-minute-strategy-game-fix) Don't worry, they ain't getting rich off it.
